import 'token.dart';
import 'ast.dart';
import 'error.dart';

/// Parser for GLP source code
class Parser {
  final List<Token> tokens;
  int _current = 0;
  Clause? _pendingClause;  // Clause parsed but belongs to different procedure

  Parser(this.tokens);

  /// Parse tokens into an AST (legacy method, skips declarations)
  Program parse() {
    // Skip any module declarations at the start
    _skipDeclarations();

    final procedures = <Procedure>[];

    while (!_isAtEnd()) {
      procedures.add(_parseProcedure());
    }

    return Program(procedures, 1, 1);
  }

  /// Parse tokens into a Module AST (includes declarations)
  Module parseModule() {
    ModuleDeclaration? moduleDecl;
    final exports = <ExportDeclaration>[];
    final imports = <ImportDeclaration>[];
    bool isStdlib = false;

    // Parse declarations at the start of the file
    while (!_isAtEnd() && _check(TokenType.MINUS)) {
      final startPos = _current;
      final startLine = _peek().line;
      final startCol = _peek().column;
      _advance(); // consume '-'

      if (!_check(TokenType.ATOM)) {
        _current = startPos;  // Back up, not a declaration
        break;
      }

      final keyword = _advance();

      switch (keyword.lexeme) {
        case 'module':
          _consume(TokenType.LPAREN, 'Expected "(" after module');
          final name = _parseModuleName();
          _consume(TokenType.RPAREN, 'Expected ")" after module name');
          _consume(TokenType.DOT, 'Expected "." after module declaration');
          moduleDecl = ModuleDeclaration(name, startLine, startCol);
          break;

        case 'stdlib':
          // -stdlib. declaration - marks this file as stdlib (no reduce generation)
          _consume(TokenType.DOT, 'Expected "." after stdlib declaration');
          isStdlib = true;
          break;

        case 'export':
          _consume(TokenType.LPAREN, 'Expected "(" after export');
          _consume(TokenType.LBRACKET, 'Expected "[" for export list');
          final procRefs = _parseProcRefList();
          _consume(TokenType.RBRACKET, 'Expected "]" after export list');
          _consume(TokenType.RPAREN, 'Expected ")" after export');
          _consume(TokenType.DOT, 'Expected "." after export declaration');
          exports.add(ExportDeclaration(procRefs, startLine, startCol));
          break;

        case 'import':
          _consume(TokenType.LPAREN, 'Expected "(" after import');
          _consume(TokenType.LBRACKET, 'Expected "[" for import list');
          final moduleNames = _parseAtomList();
          _consume(TokenType.RBRACKET, 'Expected "]" after import list');
          _consume(TokenType.RPAREN, 'Expected ")" after import');
          _consume(TokenType.DOT, 'Expected "." after import declaration');
          imports.add(ImportDeclaration(moduleNames, startLine, startCol));
          break;

        default:
          // Unknown declaration, back up to the '-'
          _current = startPos;
          break;
      }
    }

    // Parse PMT mode declarations and type definitions (after module declarations, before procedures)
    // Mode declarations: CapitalizedName(Params) := predicate(ModedArg, ...).
    // Type definitions: TypeName := constructor | constructor | ...
    final modeDeclarations = <ModeDeclaration>[];
    final typeDefinitions = <TypeDefinition>[];

    // Collect type definitions by name for merging multi-line definitions
    final typeDefsByName = <String, List<TypeConstructor>>{};
    final typeDefLocations = <String, (int, int, List<String>)>{};  // name -> (line, col, typeParams)

    while (!_isAtEnd() && _isPmtDeclaration()) {
      final results = _parseModeOrTypeDeclaration();
      for (final result in results) {
        if (result is ModeDeclaration) {
          modeDeclarations.add(result);
        } else if (result is TypeDefinition) {
          // Merge with existing definition if same type name
          final existing = typeDefsByName[result.typeName];
          if (existing != null) {
            existing.addAll(result.constructors);
          } else {
            typeDefsByName[result.typeName] = List.from(result.constructors);
            typeDefLocations[result.typeName] = (result.line, result.column, result.typeParams);
          }
        }
      }
    }

    // Convert merged type definitions to final list
    for (final entry in typeDefsByName.entries) {
      final loc = typeDefLocations[entry.key]!;
      typeDefinitions.add(TypeDefinition(
        entry.key,
        loc.$3,  // typeParams from first definition
        entry.value,
        loc.$1,
        loc.$2,
      ));
    }

    // Parse procedures
    final procedures = <Procedure>[];
    while (!_isAtEnd()) {
      procedures.add(_parseProcedure());
    }

    return Module(
      declaration: moduleDecl,
      exports: exports,
      imports: imports,
      modeDeclarations: modeDeclarations,
      typeDefinitions: typeDefinitions,
      procedures: procedures,
      isStdlib: isStdlib,
      line: 1,
      column: 1,
    );
  }

  /// Skip module declarations at start of file (for legacy parse())
  void _skipDeclarations() {
    while (!_isAtEnd() && _check(TokenType.MINUS)) {
      final startPos = _current;
      _advance(); // consume '-'

      if (!_check(TokenType.ATOM)) {
        _current = startPos;  // Back up, not a declaration
        break;
      }

      final keyword = _peek().lexeme;

      if (['module', 'export', 'import'].contains(keyword)) {
        // Skip to the next DOT
        while (!_isAtEnd() && !_check(TokenType.DOT)) {
          _advance();
        }
        if (_check(TokenType.DOT)) {
          _advance();  // consume '.'
        }
      } else {
        // Not a declaration keyword, back up
        _current = startPos;
        break;
      }
    }
  }

  /// Parse hierarchical module name (e.g., utils.list)
  String _parseModuleName() {
    final parts = <String>[];
    parts.add(_consume(TokenType.ATOM, 'Expected module name').lexeme);

    while (_match(TokenType.DOT) && _check(TokenType.ATOM)) {
      parts.add(_consume(TokenType.ATOM, 'Expected module name part').lexeme);
    }

    // Back up if we consumed a DOT but the next token wasn't ATOM
    // (This handles -module(foo). where DOT ends the declaration)
    if (_previous().type == TokenType.DOT && !_check(TokenType.ATOM)) {
      _current--;
    }

    return parts.join('.');
  }

  /// Parse list of procedure references: [proc/arity, ...]
  List<ProcRef> _parseProcRefList() {
    final refs = <ProcRef>[];

    if (_check(TokenType.RBRACKET)) return refs;  // Empty list

    refs.add(_parseProcRef());

    while (_match(TokenType.COMMA)) {
      refs.add(_parseProcRef());
    }

    return refs;
  }

  /// Parse single procedure reference: name/arity
  ProcRef _parseProcRef() {
    final name = _consume(TokenType.ATOM, 'Expected procedure name').lexeme;
    _consume(TokenType.SLASH, 'Expected "/" in procedure reference');
    final arityToken = _consume(TokenType.NUMBER, 'Expected arity');
    final arity = arityToken.literal as int;
    return ProcRef(name, arity);
  }

  /// Parse list of atoms: [atom, ...]
  List<String> _parseAtomList() {
    final atoms = <String>[];

    if (_check(TokenType.RBRACKET)) return atoms;  // Empty list

    atoms.add(_parseModuleName());

    while (_match(TokenType.COMMA)) {
      atoms.add(_parseModuleName());
    }

    return atoms;
  }

  // Procedure: one or more clauses with same head functor/arity
  Procedure _parseProcedure() {
    final clauses = <Clause>[];

    // Use pending clause if available, otherwise parse first clause
    final Clause firstClause;
    if (_pendingClause != null) {
      firstClause = _pendingClause!;
      _pendingClause = null;
    } else {
      firstClause = _parseClause();
    }
    clauses.add(firstClause);

    final name = firstClause.head.functor;
    final arity = firstClause.head.arity;

    // Parse additional clauses with same functor/arity
    // Special case: := clauses start with VARIABLE, not ATOM
    while (!_isAtEnd()) {
      // Check if next clause could be part of this procedure
      bool couldBeSameProcedure = false;

      if (_peek().type == TokenType.ATOM && _peek().lexeme == name) {
        // Same predicate name
        couldBeSameProcedure = true;
      } else if (name == ':=' && (_peek().type == TokenType.VARIABLE || _peek().type == TokenType.READER || _peek().type == TokenType.UNDERSCORE)) {
        // := clauses start with variable or underscore (e.g., "Result := X + Y" or "_ := X / 0")
        // Look ahead to see if it's followed by :=
        if (_current + 1 < tokens.length && tokens[_current + 1].type == TokenType.ASSIGN) {
          couldBeSameProcedure = true;
        }
      } else if (name == '=..' && (_peek().type == TokenType.VARIABLE || _peek().type == TokenType.READER || _peek().type == TokenType.UNDERSCORE)) {
        // =.. clauses start with variable or underscore (e.g., "X? =.. Y")
        // Look ahead to see if it's followed by =..
        if (_current + 1 < tokens.length && tokens[_current + 1].type == TokenType.UNIV) {
          couldBeSameProcedure = true;
        }
      } else if (name == '=' && (_peek().type == TokenType.VARIABLE || _peek().type == TokenType.READER || _peek().type == TokenType.UNDERSCORE)) {
        // = clauses start with variable or underscore (e.g., "X? = Y")
        // Look ahead to see if it's followed by =
        if (_current + 1 < tokens.length && tokens[_current + 1].type == TokenType.EQUALS) {
          couldBeSameProcedure = true;
        }
      }

      if (!couldBeSameProcedure) break;

      final clause = _parseClause();

      // If functor matches but arity differs, this is a different procedure
      // Store it as pending and break
      if (clause.head.functor == name && clause.head.arity != arity) {
        _pendingClause = clause;
        break;
      }

      // Verify same functor (arity already checked above for same-name case)
      if (clause.head.functor != name) {
        throw CompileError(
          'Clause for ${clause.head.functor}/${clause.head.arity} found, expected $name/$arity',
          clause.line,
          clause.column,
          phase: 'parser'
        );
      }

      clauses.add(clause);
    }

    return Procedure(name, arity, clauses, firstClause.line, firstClause.column);
  }

  // Clause: Head :- Guards | Body.
  //     or: Head :- Body.
  //     or: Head.
  Clause _parseClause() {
    final head = _parseAtom();

    List<Guard>? guards;
    List<Goal>? body;

    // Check for :- (clause with guards/body)
    if (_match(TokenType.IMPLIES)) {
      // Parse everything before | as guards (or body if no |)
      final predicates = <dynamic>[];

      predicates.add(_parseGoalOrGuard());

      while (_match(TokenType.COMMA)) {
        predicates.add(_parseGoalOrGuard());
      }

      // Check for | separator
      if (_match(TokenType.PIPE)) {
        // Everything before | were guards - convert Goal to Guard
        guards = predicates.map((g) {
          // Detect negated guards (functor starts with ~)
          final isNegated = g.functor.startsWith('~');
          final actualFunctor = isNegated ? g.functor.substring(1) : g.functor;
          return Guard(actualFunctor, g.args, g.line, g.column, negated: isNegated);
        }).toList();

        // Parse body after |
        body = <Goal>[];
        body.add(_parseGoal());

        while (_match(TokenType.COMMA)) {
          body.add(_parseGoal());
        }
      } else {
        // No | separator, so everything was body goals
        body = predicates.cast<Goal>();
      }
    }

    _consume(TokenType.DOT, 'Expected "." at end of clause');

    return Clause(head, guards: guards, body: body, line: head.line, column: head.column);
  }

  // Parse a predicate that could be either a guard or a goal
  dynamic _parseGoalOrGuard() {
    // Check for guard negation: ~G
    bool negated = false;
    int negLine = _peek().line;
    int negColumn = _peek().column;
    if (_match(TokenType.TILDE)) {
      negated = true;
      negLine = _previous().line;
      negColumn = _previous().column;

      // Check for double negation ~~G (syntactically forbidden)
      if (_check(TokenType.TILDE)) {
        throw CompileError(
          'Double negation ~~G is not allowed',
          _peek().line,
          _peek().column,
          phase: 'parser'
        );
      }
    }

    // Check for parenthesized expression: (Goal) or (Goal1 ; Goal2)
    if (_check(TokenType.LPAREN)) {
      final startToken = _advance(); // consume '('
      final firstGoal = _parseGoalOrGuard();

      if (_match(TokenType.SEMICOLON)) {
        // This is a disjunction - negation not allowed
        if (negated) {
          throw CompileError(
            'Guard negation (~) cannot be applied to disjunction',
            negLine,
            negColumn,
            phase: 'parser'
          );
        }
        final secondGoal = _parseGoalOrGuard();
        _consume(TokenType.RPAREN, 'Expected ")" after disjunction');
        // Return as ';'(Goal1, Goal2) - need to convert goals to terms
        final firstTerm = _goalToTerm(firstGoal);
        final secondTerm = _goalToTerm(secondGoal);
        return Goal(';', [firstTerm, secondTerm], startToken.line, startToken.column);
      } else {
        // Parenthesized single goal - apply negation if present
        _consume(TokenType.RPAREN, 'Expected ")" after guard');
        if (negated) {
          // Apply negation to the parsed goal
          final functor = '~${firstGoal.functor}';
          return Goal(functor, firstGoal.args, negLine, negColumn);
        }
        return firstGoal;
      }
    }

    // Check for assignment (Var := Expr) or univ (Var =.. Expr)
    if (_check(TokenType.VARIABLE) || _check(TokenType.READER)) {
      final varToken = _peek();
      final isReader = varToken.type == TokenType.READER;
      // Look ahead for := or =..
      if (tokens.length > _current + 1 && tokens[_current + 1].type == TokenType.ASSIGN) {
        _advance(); // consume variable
        _advance(); // consume :=
        final varTerm = VarTerm(varToken.lexeme, isReader, varToken.line, varToken.column);
        final expr = _parseExpression();
        return Goal(':=', [varTerm, expr], varToken.line, varToken.column);
      } else if (tokens.length > _current + 1 && tokens[_current + 1].type == TokenType.UNIV) {
        _advance(); // consume variable
        _advance(); // consume =..
        final varTerm = VarTerm(varToken.lexeme, isReader, varToken.line, varToken.column);
        final expr = _parseTerm();
        return Goal('=..', [varTerm, expr], varToken.line, varToken.column);
      } else if (tokens.length > _current + 1 && tokens[_current + 1].type == TokenType.EQUALS) {
        _advance(); // consume variable
        _advance(); // consume =
        final varTerm = VarTerm(varToken.lexeme, isReader, varToken.line, varToken.column);
        final term = _parseTerm();
        return Goal('=', [varTerm, term], varToken.line, varToken.column);
      } else if (tokens.length > _current + 1 && tokens[_current + 1].type == TokenType.HASH) {
        // Dynamic remote goal: Var # Goal (e.g., M? # factorial(5, R))
        _advance(); // consume variable
        _advance(); // consume #
        // Negation not allowed on remote goals
        if (negated) {
          throw CompileError(
            'Guard negation (~) cannot be applied to remote goal',
            negLine,
            negColumn,
            phase: 'parser'
          );
        }
        final moduleTerm = VarTerm(varToken.lexeme, isReader, varToken.line, varToken.column);
        final innerGoal = _parseGoal();
        return RemoteGoal(moduleTerm, innerGoal, varToken.line, varToken.column);
      }
    }

    // Try to parse as regular predicate first
    if (_check(TokenType.ATOM)) {
      final functorToken = _consume(TokenType.ATOM, 'Expected predicate name');
      final args = <Term>[];

      if (_match(TokenType.LPAREN)) {
        if (!_check(TokenType.RPAREN)) {
          args.add(_parseTerm());

          while (_match(TokenType.COMMA)) {
            args.add(_parseTerm());
          }
        }

        _consume(TokenType.RPAREN, 'Expected ")" after arguments');
      }

      // Check for static remote goal: atom # goal (e.g., math # factorial(5, R))
      if (_match(TokenType.HASH)) {
        // Module name cannot have arguments
        if (args.isNotEmpty) {
          throw CompileError(
            'Module name cannot have arguments: ${functorToken.lexeme}',
            functorToken.line,
            functorToken.column,
            phase: 'parser'
          );
        }
        // Negation not allowed on remote goals
        if (negated) {
          throw CompileError(
            'Guard negation (~) cannot be applied to remote goal',
            negLine,
            negColumn,
            phase: 'parser'
          );
        }
        final moduleTerm = ConstTerm(functorToken.lexeme, functorToken.line, functorToken.column);
        final innerGoal = _parseGoal();
        return RemoteGoal(moduleTerm, innerGoal, functorToken.line, functorToken.column);
      }

      // Check if followed by = (e.g., foo = bar, or foo(a) = X)
      if (_match(TokenType.EQUALS)) {
        final leftTerm = args.isEmpty
            ? ConstTerm(functorToken.lexeme, functorToken.line, functorToken.column)
            : StructTerm(functorToken.lexeme, args, functorToken.line, functorToken.column);
        final rightTerm = _parseTerm();
        // Negation not allowed on unification goals
        if (negated) {
          throw CompileError(
            'Guard negation (~) cannot be applied to unification',
            negLine,
            negColumn,
            phase: 'parser'
          );
        }
        return Goal('=', [leftTerm, rightTerm], functorToken.line, functorToken.column);
      }

      // Return as Goal for now (will be cast to Guard if before |)
      // Use ~functor convention if negated (will be detected during Guard conversion)
      final functor = negated ? '~${functorToken.lexeme}' : functorToken.lexeme;
      return Goal(functor, args, negated ? negLine : functorToken.line, negated ? negColumn : functorToken.column);
    }

    // Otherwise, try to parse as infix comparison (e.g., X < Y, X? mod P? =:= 0)
    // Use _parseExpression(6) to parse arithmetic but stop at comparison operators
    final left = _parseExpression(6);

    // Check for comparison operator
    if (_check(TokenType.LESS) || _check(TokenType.GREATER) ||
        _check(TokenType.LESS_EQUAL) || _check(TokenType.GREATER_EQUAL) ||
        _check(TokenType.EQUALS) || _check(TokenType.ARITH_EQUAL) ||
        _check(TokenType.ARITH_NOT_EQUAL) || _check(TokenType.GROUND_EQUAL)) {
      final opToken = _advance();
      final right = _parseExpression(6);

      // Transform infix to prefix: X < Y → <(X, Y)
      // For negation: ~(X =?= Y) → use ~=?= functor convention
      final functor = negated ? '~${opToken.lexeme}' : opToken.lexeme;
      return Goal(functor, [left, right], negated ? negLine : opToken.line, negated ? negColumn : opToken.column);
    }

    // Not a valid guard or goal
    throw CompileError(
      'Expected predicate name or comparison',
      _peek().line,
      _peek().column,
      phase: 'parser'
    );
  }

  // Convert a Goal to a Term representation (for disjunction)
  Term _goalToTerm(dynamic goal) {
    if (goal is Goal) {
      return StructTerm(goal.functor, goal.args, goal.line, goal.column);
    }
    throw CompileError('Expected goal', 0, 0, phase: 'parser');
  }

  // Atom: functor(arg1, arg2, ...) or Var := Expr or Var =.. Expr (for clause heads)
  Atom _parseAtom() {
    // Check for := or =.. pattern: Var := Expr or Var =.. Expr or _ := Expr
    if (_check(TokenType.VARIABLE) || _check(TokenType.READER) || _check(TokenType.UNDERSCORE)) {
      final varToken = _advance();
      final isReader = varToken.type == TokenType.READER;
      final isUnderscore = varToken.type == TokenType.UNDERSCORE;
      if (_match(TokenType.ASSIGN)) {
        // Parse as ':='(Var, Expr) or ':='(_, Expr)
        final lhsTerm = isUnderscore
            ? UnderscoreTerm(varToken.line, varToken.column)
            : VarTerm(varToken.lexeme, isReader, varToken.line, varToken.column);
        final expr = _parseTerm();
        return Atom(':=', [lhsTerm, expr], varToken.line, varToken.column);
      } else if (_match(TokenType.UNIV)) {
        // Parse as '=..'(Var, Expr)
        final varTerm = VarTerm(varToken.lexeme, isReader, varToken.line, varToken.column);
        final expr = _parseTerm();
        return Atom('=..', [varTerm, expr], varToken.line, varToken.column);
      } else if (_match(TokenType.EQUALS)) {
        // Parse as '='(Var, Term) - unification
        final varTerm = VarTerm(varToken.lexeme, isReader, varToken.line, varToken.column);
        final term = _parseTerm();
        return Atom('=', [varTerm, term], varToken.line, varToken.column);
      } else {
        // Not an assignment - put variable back by rewinding
        _current--;
      }
    }

    final functorToken = _consume(TokenType.ATOM, 'Expected predicate name');
    final args = <Term>[];

    if (_match(TokenType.LPAREN)) {
      if (!_check(TokenType.RPAREN)) {
        args.add(_parseTerm());

        while (_match(TokenType.COMMA)) {
          args.add(_parseTerm());
        }
      }

      _consume(TokenType.RPAREN, 'Expected ")" after arguments');
    }

    // Check if this is followed by =.. (e.g., foo(a,b) =.. L)
    if (_match(TokenType.UNIV)) {
      // Convert the already-parsed atom to a StructTerm
      final leftTerm = StructTerm(functorToken.lexeme, args, functorToken.line, functorToken.column);
      final rightTerm = _parseTerm();
      return Atom('=..', [leftTerm, rightTerm], functorToken.line, functorToken.column);
    }

    // Check if this is followed by = (e.g., foo = bar, foo(a) = X)
    if (_match(TokenType.EQUALS)) {
      final leftTerm = args.isEmpty
          ? ConstTerm(functorToken.lexeme, functorToken.line, functorToken.column)
          : StructTerm(functorToken.lexeme, args, functorToken.line, functorToken.column);
      final rightTerm = _parseTerm();
      return Atom('=', [leftTerm, rightTerm], functorToken.line, functorToken.column);
    }

    return Atom(functorToken.lexeme, args, functorToken.line, functorToken.column);
  }

  // Goal: same as Atom, or assignment (Var := Expr) or univ (Var =.. Expr)
  // Also handles remote goals: Module # Goal
  Goal _parseGoal() {
    // Check for assignment or univ: Var := Expr or Var =.. Expr
    // Also check for dynamic remote goal: Var # Goal
    if (_check(TokenType.VARIABLE) || _check(TokenType.READER)) {
      final varToken = _advance();
      final isReader = varToken.type == TokenType.READER;

      // Check for dynamic remote goal: Var # Goal (e.g., M # factorial(5, R))
      if (_match(TokenType.HASH)) {
        final moduleTerm = VarTerm(varToken.lexeme, isReader, varToken.line, varToken.column);
        final innerGoal = _parseGoal();
        return RemoteGoal(moduleTerm, innerGoal, varToken.line, varToken.column);
      } else if (_match(TokenType.ASSIGN)) {
        // Parse as ':='(Var, Expr)
        final varTerm = VarTerm(varToken.lexeme, isReader, varToken.line, varToken.column);
        final expr = _parseTerm();
        return Goal(':=', [varTerm, expr], varToken.line, varToken.column);
      } else if (_match(TokenType.UNIV)) {
        // Parse as '=..'(Var, Expr)
        final varTerm = VarTerm(varToken.lexeme, isReader, varToken.line, varToken.column);
        final expr = _parseTerm();
        return Goal('=..', [varTerm, expr], varToken.line, varToken.column);
      } else if (_match(TokenType.EQUALS)) {
        // Parse as '='(Var, Term) - unification
        final varTerm = VarTerm(varToken.lexeme, isReader, varToken.line, varToken.column);
        final term = _parseTerm();
        return Goal('=', [varTerm, term], varToken.line, varToken.column);
      } else {
        // Not an assignment or univ - this is an error in goal position
        throw CompileError(
          'Expected predicate name or assignment, got variable "${varToken.lexeme}"',
          varToken.line,
          varToken.column,
          phase: 'parser'
        );
      }
    }

    final functorToken = _consume(TokenType.ATOM, 'Expected predicate name');
    final args = <Term>[];

    if (_match(TokenType.LPAREN)) {
      if (!_check(TokenType.RPAREN)) {
        args.add(_parseTerm());

        while (_match(TokenType.COMMA)) {
          args.add(_parseTerm());
        }
      }

      _consume(TokenType.RPAREN, 'Expected ")" after arguments');
    }

    // Check for static remote goal: Module # Goal (e.g., math # factorial(5, R))
    if (_match(TokenType.HASH)) {
      // Module name cannot have arguments
      if (args.isNotEmpty) {
        throw CompileError(
          'Module name cannot have arguments: ${functorToken.lexeme}',
          functorToken.line,
          functorToken.column,
          phase: 'parser'
        );
      }
      final moduleTerm = ConstTerm(functorToken.lexeme, functorToken.line, functorToken.column);
      final innerGoal = _parseGoal();
      return RemoteGoal(moduleTerm, innerGoal, functorToken.line, functorToken.column);
    }

    // Check if this is followed by =.. (e.g., foo(a,b) =.. L)
    if (_match(TokenType.UNIV)) {
      // Convert the already-parsed atom to a StructTerm
      final leftTerm = StructTerm(functorToken.lexeme, args, functorToken.line, functorToken.column);
      final rightTerm = _parseTerm();
      return Goal('=..', [leftTerm, rightTerm], functorToken.line, functorToken.column);
    }

    return Goal(functorToken.lexeme, args, functorToken.line, functorToken.column);
  }

  // Guard: same as Goal but marked as guard
  Guard _parseGuard() {
    final functorToken = _consume(TokenType.ATOM, 'Expected guard predicate name');
    final args = <Term>[];

    if (_match(TokenType.LPAREN)) {
      if (!_check(TokenType.RPAREN)) {
        args.add(_parseTerm());

        while (_match(TokenType.COMMA)) {
          args.add(_parseTerm());
        }
      }

      _consume(TokenType.RPAREN, 'Expected ")" after arguments');
    }

    return Guard(functorToken.lexeme, args, functorToken.line, functorToken.column);
  }

  // Term: variable, structure, list, constant, underscore, tuple, or expression
  Term _parseTerm() {
    // Try to parse as expression (handles arithmetic operators)
    return _parseExpression();
  }

  // Expression parsing with precedence (Pratt parsing)
  // This handles arithmetic operators with proper precedence
  Term _parseExpression([int minPrecedence = 0]) {
    var left = _parsePrimary();

    while (_isOperator(_peek()) && _precedence(_peek()) >= minPrecedence) {
      final op = _advance();
      final right = _parseExpression(_precedence(op) + 1);
      left = StructTerm(_operatorFunctor(op), [left, right], op.line, op.column);
    }

    return left;
  }

  // Primary expression: variable, number, string, list, structure, parenthesized, unary minus
  Term _parsePrimary() {
    // Unary minus: -X becomes neg(X)
    if (_match(TokenType.MINUS)) {
      final minusToken = _previous();
      final operand = _parsePrimary();
      return StructTerm('neg', [operand], minusToken.line, minusToken.column);
    }

    // Variable or Reader - check for := assignment
    if (_check(TokenType.VARIABLE) || _check(TokenType.READER)) {
      final token = _advance();
      final isReader = token.type == TokenType.READER;

      // Check for := assignment (Var := Expr)
      if (_match(TokenType.ASSIGN)) {
        final varTerm = VarTerm(token.lexeme, isReader, token.line, token.column);
        final expr = _parseExpression();
        return StructTerm(':=', [varTerm, expr], token.line, token.column);
      }

      return VarTerm(token.lexeme, isReader, token.line, token.column);
    }

    // Underscore (anonymous variable)
    if (_match(TokenType.UNDERSCORE)) {
      final token = _previous();
      return UnderscoreTerm(token.line, token.column);
    }

    // Number
    if (_check(TokenType.NUMBER)) {
      final token = _advance();
      // Check for invalid reader mark on number
      if (_check(TokenType.QUESTION)) {
        throw CompileError(
          'Reader mark "?" can only be applied to variables, not numbers',
          _peek().line,
          _peek().column,
          phase: 'parser'
        );
      }
      return ConstTerm(token.literal, token.line, token.column);
    }

    // String
    if (_check(TokenType.STRING)) {
      final token = _advance();
      // Check for invalid reader mark on string
      if (_check(TokenType.QUESTION)) {
        throw CompileError(
          'Reader mark "?" can only be applied to variables, not strings',
          _peek().line,
          _peek().column,
          phase: 'parser'
        );
      }
      return ConstTerm(token.literal, token.line, token.column);
    }

    // List
    if (_check(TokenType.LBRACKET)) {
      return _parseList();
    }

    // Parenthesized expression - could be tuple (A, B) or single term (A) or arithmetic (A + B)
    if (_match(TokenType.LPAREN)) {
      final startToken = _previous();
      final terms = <Term>[];

      // Parse first term (which may be an expression)
      terms.add(_parseExpression());

      // Check for comma - indicates tuple/conjunction
      if (_match(TokenType.COMMA)) {
        // Build right-associative tuple: (A, B, C) = ','(A, ','(B, C))
        terms.add(_parseExpression());

        while (_match(TokenType.COMMA)) {
          terms.add(_parseExpression());
        }

        _consume(TokenType.RPAREN, 'Expected ")" after tuple');

        // Build right-associative structure
        Term result = terms.last;
        for (int i = terms.length - 2; i >= 0; i--) {
          result = StructTerm(',', [terms[i], result], startToken.line, startToken.column);
        }

        return result;
      } else {
        // Single parenthesized expression - return it
        _consume(TokenType.RPAREN, 'Expected ")" after expression');
        return terms[0];
      }
    }

    // Structure or Constant Atom
    if (_check(TokenType.ATOM)) {
      final functorToken = _advance();

      // Structure with arguments
      if (_match(TokenType.LPAREN)) {
        final args = <Term>[];

        if (!_check(TokenType.RPAREN)) {
          args.add(_parseExpression());

          while (_match(TokenType.COMMA)) {
            args.add(_parseExpression());
          }
        }

        _consume(TokenType.RPAREN, 'Expected ")" after structure arguments');

        // Check for invalid reader mark on structure
        if (_check(TokenType.QUESTION)) {
          throw CompileError(
            'Reader mark "?" can only be applied to variables, not structures like ${functorToken.lexeme}(...)',
            _peek().line,
            _peek().column,
            phase: 'parser'
          );
        }

        return StructTerm(functorToken.lexeme, args, functorToken.line, functorToken.column);
      } else {
        // Constant atom - check for invalid reader mark
        if (_check(TokenType.QUESTION)) {
          throw CompileError(
            'Reader mark "?" can only be applied to variables, not constants like "${functorToken.lexeme}"',
            _peek().line,
            _peek().column,
            phase: 'parser'
          );
        }
        return ConstTerm(functorToken.lexeme, functorToken.line, functorToken.column);
      }
    }

    throw CompileError(
      'Expected term, got ${_peek().type}',
      _peek().line,
      _peek().column,
      phase: 'parser'
    );
  }

  // Check if token is an arithmetic operator, # (module operator), or \ (difference list)
  bool _isOperator(Token token) {
    return token.type == TokenType.PLUS ||
           token.type == TokenType.MINUS ||
           token.type == TokenType.STAR ||
           token.type == TokenType.SLASH ||
           token.type == TokenType.SLASH_SLASH ||
           token.type == TokenType.MOD ||
           token.type == TokenType.LESS ||
           token.type == TokenType.GREATER ||
           token.type == TokenType.LESS_EQUAL ||
           token.type == TokenType.GREATER_EQUAL ||
           token.type == TokenType.EQUALS ||
           token.type == TokenType.ARITH_EQUAL ||
           token.type == TokenType.ARITH_NOT_EQUAL ||
           token.type == TokenType.HASH ||
           token.type == TokenType.BACKSLASH;
  }

  // Get operator precedence
  int _precedence(Token op) {
    switch (op.type) {
      case TokenType.STAR:
      case TokenType.SLASH:
      case TokenType.SLASH_SLASH:
      case TokenType.MOD:
        return 20;  // Multiplicative
      case TokenType.PLUS:
      case TokenType.MINUS:
        return 10;  // Additive
      case TokenType.HASH:
        return 2;   // Module operator (very low, so M # foo(X,Y) parses correctly)
      case TokenType.BACKSLASH:
        return 1;   // Difference list operator (lowest, so [H|T]\T parses correctly)
      case TokenType.LESS:
      case TokenType.GREATER:
      case TokenType.LESS_EQUAL:
      case TokenType.GREATER_EQUAL:
      case TokenType.EQUALS:
      case TokenType.ARITH_EQUAL:
      case TokenType.ARITH_NOT_EQUAL:
        return 5;   // Comparison (lower than arithmetic)
      default:
        return 0;
    }
  }

  // Get operator functor name for AST
  String _operatorFunctor(Token op) {
    switch (op.type) {
      case TokenType.PLUS:
        return '+';
      case TokenType.MINUS:
        return '-';
      case TokenType.STAR:
        return '*';
      case TokenType.SLASH:
        return '/';
      case TokenType.SLASH_SLASH:
        return '//';
      case TokenType.MOD:
        return 'mod';
      case TokenType.LESS:
        return '<';
      case TokenType.GREATER:
        return '>';
      case TokenType.LESS_EQUAL:
        return '=<';
      case TokenType.GREATER_EQUAL:
        return '>=';
      case TokenType.EQUALS:
        return '=';
      case TokenType.ARITH_EQUAL:
        return '=:=';
      case TokenType.ARITH_NOT_EQUAL:
        return '=\\=';
      case TokenType.HASH:
        return '#';
      case TokenType.BACKSLASH:
        return '\\';
      default:
        throw CompileError(
          'Unknown operator: ${op.type}',
          op.line,
          op.column,
          phase: 'parser'
        );
    }
  }

  // List: [], [H|T], [X], [X,Y,Z], [X,Y,Z|T]
  Term _parseList() {
    final bracketToken = _consume(TokenType.LBRACKET, 'Expected "["');

    // Empty list []
    if (_match(TokenType.RBRACKET)) {
      // Check for invalid reader mark on list
      if (_check(TokenType.QUESTION)) {
        throw CompileError(
          'Reader mark "?" can only be applied to variables, not lists',
          _peek().line,
          _peek().column,
          phase: 'parser'
        );
      }
      return ListTerm(null, null, bracketToken.line, bracketToken.column);
    }

    // Parse elements
    final elements = <Term>[];
    Term? tail;

    elements.add(_parseTerm());

    // Parse remaining elements and check for tail
    while (_match(TokenType.COMMA)) {
      elements.add(_parseTerm());
    }

    // Check for tail syntax [H|T] or [X,Y|T]
    if (_match(TokenType.PIPE)) {
      tail = _parseTerm();
      _consume(TokenType.RBRACKET, 'Expected "]" after list tail');

      // Check for invalid reader mark on list
      if (_check(TokenType.QUESTION)) {
        throw CompileError(
          'Reader mark "?" can only be applied to variables, not lists',
          _peek().line,
          _peek().column,
          phase: 'parser'
        );
      }

      // Build right-associative list: [X,Y,Z|T] -> [X|[Y|[Z|T]]]
      Term result = tail;
      for (int i = elements.length - 1; i >= 0; i--) {
        result = ListTerm(elements[i], result, bracketToken.line, bracketToken.column);
      }
      return result;
    }

    _consume(TokenType.RBRACKET, 'Expected "]" after list elements');

    // Check for invalid reader mark on list
    if (_check(TokenType.QUESTION)) {
      throw CompileError(
        'Reader mark "?" can only be applied to variables, not lists',
        _peek().line,
        _peek().column,
        phase: 'parser'
      );
    }

    // Build right-associative list: [X, Y, Z] -> [X|[Y|[Z|[]]]]
    Term result = ListTerm(null, null, bracketToken.line, bracketToken.column); // []
    for (int i = elements.length - 1; i >= 0; i--) {
      result = ListTerm(elements[i], result, bracketToken.line, bracketToken.column);
    }

    return result;
  }

  // Helper methods
  bool _match(TokenType type) {
    if (_check(type)) {
      _advance();
      return true;
    }
    return false;
  }

  bool _check(TokenType type) {
    if (_isAtEnd()) return false;
    return _peek().type == type;
  }

  Token _advance() {
    if (!_isAtEnd()) _current++;
    return _previous();
  }

  Token _peek() => tokens[_current];
  Token _previous() => tokens[_current - 1];
  bool _isAtEnd() => _peek().type == TokenType.EOF;

  Token _consume(TokenType type, String message) {
    if (_check(type)) return _advance();

    throw CompileError(message, _peek().line, _peek().column, phase: 'parser');
  }

  // ============================================================================
  // PMT (Polymorphic Moded Types) Parser Methods
  // ============================================================================

  /// Check if a string is capitalized (starts with uppercase letter)
  bool _isCapitalized(String s) {
    if (s.isEmpty) return false;
    final first = s.codeUnitAt(0);
    return first >= 65 && first <= 90;  // A-Z
  }

  /// Check if we're at a PMT mode declaration: CapitalizedName(...) := pred(...).
  /// or CapitalizedName := pred(...).
  /// Note: Capitalized names are tokenized as VARIABLE, not ATOM
  bool _isPmtDeclaration() {
    // PMT type names are capitalized, so they're tokenized as VARIABLE
    if (!_check(TokenType.VARIABLE)) return false;

    // Look ahead for := (optionally with type params in between)
    final saved = _current;

    _advance();  // consume type name

    // Skip optional type params: (A, B, ...)
    if (_check(TokenType.LPAREN)) {
      _advance();
      int depth = 1;
      while (!_isAtEnd() && depth > 0) {
        if (_check(TokenType.LPAREN)) depth++;
        if (_check(TokenType.RPAREN)) depth--;
        _advance();
      }
    }

    // Check for :=
    final isDecl = _check(TokenType.ASSIGN);

    _current = saved;  // restore position
    return isDecl;
  }

  /// Parse a PMT mode declaration: TypeName(Params) := predicate(ModedArg, ...).
  ModeDeclaration _parseModeDeclaration() {
    // Type names are capitalized, so they're tokenized as VARIABLE
    final typeNameToken = _consume(TokenType.VARIABLE, 'Expected type name');
    final typeName = typeNameToken.lexeme;

    // Optional type parameters: (A, B, ...) - also capitalized, so VARIABLE
    final typeParams = <String>[];
    if (_match(TokenType.LPAREN)) {
      // Parse type params (single capital letters like A, B)
      typeParams.add(_consume(TokenType.VARIABLE, 'Expected type parameter').lexeme);
      while (_match(TokenType.COMMA)) {
        typeParams.add(_consume(TokenType.VARIABLE, 'Expected type parameter').lexeme);
      }
      _consume(TokenType.RPAREN, 'Expected ")" after type parameters');
    }

    _consume(TokenType.ASSIGN, 'Expected ":=" in mode declaration');

    // Predicate name (lowercase atom)
    final predToken = _consume(TokenType.ATOM, 'Expected predicate name');
    final predicate = predToken.lexeme;

    // Arguments with modes: (ModedArg, ModedArg, ...)
    final args = <ModedArg>[];
    _consume(TokenType.LPAREN, 'Expected "(" after predicate name');
    if (!_check(TokenType.RPAREN)) {
      args.add(_parseModedArg());
      while (_match(TokenType.COMMA)) {
        args.add(_parseModedArg());
      }
    }
    _consume(TokenType.RPAREN, 'Expected ")" after moded arguments');
    _consume(TokenType.DOT, 'Expected "." after mode declaration');

    return ModeDeclaration(
      typeName,
      typeParams,
      predicate,
      args,
      typeNameToken.line,
      typeNameToken.column,
    );
  }

  /// Parse either a mode declaration or a type definition
  /// Returns list of ModeDeclaration or TypeDefinition based on RHS structure
  /// Union of mode declarations returns multiple ModeDeclarations
  List<AstNode> _parseModeOrTypeDeclaration() {
    // Type names are capitalized, so they're tokenized as VARIABLE
    final typeNameToken = _consume(TokenType.VARIABLE, 'Expected type name');
    final typeName = typeNameToken.lexeme;

    // Optional type parameters: (A, B, ...) - also capitalized, so VARIABLE
    final typeParams = <String>[];
    if (_match(TokenType.LPAREN)) {
      typeParams.add(_consume(TokenType.VARIABLE, 'Expected type parameter').lexeme);
      while (_match(TokenType.COMMA)) {
        typeParams.add(_consume(TokenType.VARIABLE, 'Expected type parameter').lexeme);
      }
      _consume(TokenType.RPAREN, 'Expected ")" after type parameters');
    }

    _consume(TokenType.ASSIGN, 'Expected ":=" in declaration');

    // Now we need to determine if this is a mode declaration or type definition
    // Look at the RHS:
    // - Mode declaration: pred(Type?, Type) - predicate with moded args
    // - Type definition: atom | struct | [] | [_|T] | union of these
    // - Union of mode declarations: pred(T?, T) | pred(T, T?)

    // Parse all constructors/alternatives separated by |
    final constructors = <TypeConstructor>[];
    final modeAlternatives = <_ModeDeclarationParts>[];
    bool firstHasModeMarkers = false;
    String? firstPredicateName;

    // Parse first constructor/alternative
    final firstResult = _parseConstructorOrModeArg();
    if (firstResult is _ModeDeclarationParts) {
      firstPredicateName = firstResult.predicate;
      firstHasModeMarkers = firstResult.hasModeMarkers;
      if (firstResult.hasModeMarkers || firstResult.args.isEmpty) {
        modeAlternatives.add(firstResult);
      } else {
        // First alternative is struct constructor (no mode markers)
        final structArgs = firstResult.args.map((a) => TypeArg(a.typeName, a.typeParams, isReader: a.isReader)).toList();
        constructors.add(StructConstructor(firstResult.predicate, structArgs));
      }
    } else {
      constructors.add(firstResult as TypeConstructor);
    }

    // Parse additional alternatives with |
    while (_match(TokenType.PIPE)) {
      final result = _parseConstructorOrModeArg();
      if (result is _ModeDeclarationParts) {
        if (result.hasModeMarkers) {
          // Union of mode declarations
          if (modeAlternatives.isEmpty && firstPredicateName != null) {
            // First was a struct constructor, but this is a mode - error
            throw CompileError(
              'Cannot mix type constructors and mode declarations in union.',
              typeNameToken.line,
              typeNameToken.column,
              phase: 'parser',
            );
          }
          // Verify same predicate name and arity
          if (modeAlternatives.isNotEmpty) {
            final first = modeAlternatives.first;
            if (result.predicate != first.predicate) {
              throw CompileError(
                'Mode union must use same predicate name: expected "${first.predicate}", got "${result.predicate}".',
                typeNameToken.line,
                typeNameToken.column,
                phase: 'parser',
              );
            }
            if (result.args.length != first.args.length) {
              throw CompileError(
                'Mode union must have same arity: expected ${first.args.length}, got ${result.args.length}.',
                typeNameToken.line,
                typeNameToken.column,
                phase: 'parser',
              );
            }
          }
          modeAlternatives.add(result);
        } else {
          // Struct constructor without mode markers
          final structArgs = result.args.map((a) => TypeArg(a.typeName, a.typeParams, isReader: a.isReader)).toList();
          constructors.add(StructConstructor(result.predicate, structArgs));
        }
      } else {
        constructors.add(result as TypeConstructor);
      }
    }

    _consume(TokenType.DOT, 'Expected "." after declaration');

    // Decide what to return based on what we parsed
    if (modeAlternatives.isNotEmpty) {
      // Mode declaration(s): return one ModeDeclaration per alternative
      return modeAlternatives.map((parts) => ModeDeclaration(
        typeName,
        typeParams,
        parts.predicate,
        parts.args,
        typeNameToken.line,
        typeNameToken.column,
      )).toList();
    } else if (firstPredicateName != null && !firstHasModeMarkers && constructors.isEmpty) {
      // Edge case: single struct with args but no mode markers treated as struct constructor
      // This shouldn't happen if we handled first result correctly above
      return [TypeDefinition(typeName, typeParams, constructors, typeNameToken.line, typeNameToken.column)];
    } else {
      // This is a type definition with constructors
      return [TypeDefinition(typeName, typeParams, constructors, typeNameToken.line, typeNameToken.column)];
    }
  }

  /// Parse a constructor or mode declaration arguments
  /// Returns TypeConstructor for type definitions, _ModeDeclarationParts for mode declarations
  dynamic _parseConstructorOrModeArg() {
    // Check for tuple constructors: (X, Y, ...)
    if (_check(TokenType.LPAREN)) {
      return _parseTupleConstructor();
    }

    // Check for list constructors: [] or [_|T]
    if (_check(TokenType.LBRACKET)) {
      return _parseListConstructor();
    }

    // Check for atom or struct
    if (_check(TokenType.ATOM)) {
      final token = _advance();

      // Nullary atom (type constructor)
      if (!_check(TokenType.LPAREN)) {
        return AtomConstructor(token.lexeme);
      }

      // Has arguments - could be struct constructor or mode declaration
      _advance();  // consume (
      final args = <ModedArg>[];
      bool hasModeMarkers = false;

      if (!_check(TokenType.RPAREN)) {
        final arg = _parseModedArg();
        if (arg.isReader) hasModeMarkers = true;
        args.add(arg);

        while (_match(TokenType.COMMA)) {
          final arg = _parseModedArg();
          if (arg.isReader) hasModeMarkers = true;
          args.add(arg);
        }
      }

      _consume(TokenType.RPAREN, 'Expected ")" after arguments');

      // If no args, it's a nullary mode declaration (pred())
      if (args.isEmpty) {
        return _ModeDeclarationParts(token.lexeme, args, false);
      }

      return _ModeDeclarationParts(token.lexeme, args, hasModeMarkers);
    }

    // Check for VARIABLE (could be type param reference in type definition)
    if (_check(TokenType.VARIABLE)) {
      final token = _advance();
      // Check for () which makes it a nullary mode declaration
      if (_match(TokenType.LPAREN)) {
        _consume(TokenType.RPAREN, 'Expected ")" after predicate name');
        return _ModeDeclarationParts(token.lexeme, [], false);
      }
      // Type parameter reference as constructor (rare but possible)
      return AtomConstructor(token.lexeme);
    }

    throw CompileError(
      'Expected constructor or predicate',
      _peek().line,
      _peek().column,
      phase: 'parser',
    );
  }

  /// Parse a list constructor: [] or [head|tail]
  ListConstructor _parseListConstructor() {
    _consume(TokenType.LBRACKET, 'Expected "["');

    // Empty list []
    if (_match(TokenType.RBRACKET)) {
      return const ListConstructor(null, null);
    }

    // Parse head: _ or _? or TypeName or TypeName?
    final head = _parseTypeArgForList();

    // Expect |
    _consume(TokenType.PIPE, 'Expected "|" in list constructor');

    // Parse tail: TypeName or TypeName?
    final tail = _parseTypeArgForList();

    _consume(TokenType.RBRACKET, 'Expected "]" after list constructor');

    return ListConstructor(head, tail);
  }

  /// Parse a tuple constructor: (X, Goals(X)), (A, B), etc.
  TupleConstructor _parseTupleConstructor() {
    _consume(TokenType.LPAREN, 'Expected "("');

    final elements = <TypeArg>[];

    // Parse first element
    elements.add(_parseTypeArgForTuple());

    // Parse remaining elements
    while (_match(TokenType.COMMA)) {
      elements.add(_parseTypeArgForTuple());
    }

    _consume(TokenType.RPAREN, 'Expected ")" after tuple');

    return TupleConstructor(elements);
  }

  /// Parse a type arg for tuple: TypeName, TypeName?, TypeName(Params), etc.
  TypeArg _parseTypeArgForTuple() {
    // Type name (VARIABLE because capitalized)
    if (_check(TokenType.VARIABLE)) {
      final token = _advance();

      // Optional type params: Goals(X) -> Goals with param X
      final typeParams = <String>[];
      if (_match(TokenType.LPAREN)) {
        typeParams.add(_parseTypeParam());
        while (_match(TokenType.COMMA)) {
          typeParams.add(_parseTypeParam());
        }
        _consume(TokenType.RPAREN, 'Expected ")" after type parameters');
      }

      // Check for ?
      final isReader = _match(TokenType.QUESTION);
      return TypeArg(token.lexeme, typeParams, isReader: isReader);
    }

    // Reader type without params: Type?
    if (_check(TokenType.READER)) {
      final token = _advance();
      return TypeArg(token.lexeme, [], isReader: true);
    }

    throw CompileError(
      'Expected type in tuple',
      _peek().line,
      _peek().column,
      phase: 'parser',
    );
  }

  /// Parse a type arg for list constructor: _ or _? or TypeName or TypeName?
  TypeArg _parseTypeArgForList() {
    // Underscore
    if (_match(TokenType.UNDERSCORE)) {
      // Check for ?
      final isReader = _match(TokenType.QUESTION);
      return TypeArg('_', [], isReader: isReader);
    }

    // Reader type without params: Type?
    if (_check(TokenType.READER)) {
      final token = _advance();
      return TypeArg(token.lexeme, [], isReader: true);
    }

    // Type name (VARIABLE because capitalized)
    if (_check(TokenType.VARIABLE)) {
      final token = _advance();

      // Optional type params
      final typeParams = <String>[];
      if (_match(TokenType.LPAREN)) {
        typeParams.add(_parseTypeParam());
        while (_match(TokenType.COMMA)) {
          typeParams.add(_parseTypeParam());
        }
        _consume(TokenType.RPAREN, 'Expected ")" after type parameters');
      }

      // Check for ?
      final isReader = _match(TokenType.QUESTION);
      return TypeArg(token.lexeme, typeParams, isReader: isReader);
    }

    throw CompileError(
      'Expected type in list constructor',
      _peek().line,
      _peek().column,
      phase: 'parser',
    );
  }

  /// Parse a moded argument: TypeName(Params)? or TypeName(Params)
  /// Note: The lexer tokenizes "Num?" as a single READER token with lexeme "Num"
  ModedArg _parseModedArg() {
    // Type names can be:
    // - VARIABLE: "Num" (writer) or "List" (with type params)
    // - READER: "Num?" (reader without type params)
    String typeName;
    bool isReader;

    if (_check(TokenType.READER)) {
      // Simple reader type without type params: Num?
      final token = _advance();
      typeName = token.lexeme;
      isReader = true;
      // No type params possible since ? was consumed by lexer
      return ModedArg(typeName, [], isReader: isReader);
    }

    // VARIABLE: type name possibly with type params
    final typeToken = _consume(TokenType.VARIABLE, 'Expected type name');
    typeName = typeToken.lexeme;

    // Optional type parameters: (A, B) - also capitalized, so VARIABLE or READER
    final typeParams = <String>[];
    if (_match(TokenType.LPAREN)) {
      typeParams.add(_parseTypeParam());
      while (_match(TokenType.COMMA)) {
        typeParams.add(_parseTypeParam());
      }
      _consume(TokenType.RPAREN, 'Expected ")" after type parameters');
    }

    // Check for reader marker (?) after type params
    isReader = _match(TokenType.QUESTION);

    return ModedArg(typeName, typeParams, isReader: isReader);
  }

  /// Parse a type parameter (VARIABLE)
  String _parseTypeParam() {
    return _consume(TokenType.VARIABLE, 'Expected type parameter').lexeme;
  }
}

/// Helper class to hold parsed mode declaration parts during disambiguation
class _ModeDeclarationParts {
  final String predicate;
  final List<ModedArg> args;
  final bool hasModeMarkers;

  _ModeDeclarationParts(this.predicate, this.args, this.hasModeMarkers);
}
