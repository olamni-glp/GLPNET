import 'machine_state.dart';
import 'heap_fcp.dart';
import 'suspension.dart';
import 'terms.dart';

class CommitOps {
  /// Apply tentative writer substitution σ̂w (FCP-exact two-cell semantics)
  /// Implements FCP emulate.h do_commit1 lines 217-258
  /// Critical: Address-based dereferencing (FCP line 233) prevents variable chains
  static List<GoalRef> applySigmaHatFCP({
    required HeapFCP heap,
    required Map<int, Object?> sigmaHat,
  }) {
    // print('[TRACE Commit FCP] Applying σ̂w to heap (${sigmaHat.length} bindings):');
    for (final entry in sigmaHat.entries) {
      // print('  W${entry.key} → ${entry.value}');
    }

    final activations = <GoalRef>[];

    // Defensive WxW validation before applying bindings
    for (final entry in sigmaHat.entries) {
      final value = entry.value;
      if (value is VarRef && !value.isReader) {
        final clauseWriterId = entry.key;
        final queryWriterId = value.varId;
        // Check if both are unbound (WxW violation)
        if (!heap.isWriterBound(clauseWriterId) && !heap.isWriterBound(queryWriterId)) {
          throw StateError('WxW violation in applySigmaHatFCP: W$clauseWriterId → W$queryWriterId (both unbound)');
        }
      }
    }

    for (final entry in sigmaHat.entries) {
      final varId = entry.key;
      var value = entry.value;

      // Skip null values (writer declared but not bound in HEAD)
      if (value == null) continue;

      // Convert varId to addresses
      final (wAddr, rAddr) = heap.varTable[varId]!;

      // FCP line 226: CRITICAL - dereference by ADDRESS before binding
      // This prevents W1009→R1014→nil chains
      // IMPORTANT: Use reader address if VarRef is reader, writer address if writer
      if (value is VarRef) {
        final (targetWAddr, targetRAddr) = heap.varTable[value.varId]!;
        final targetAddr = value.isReader ? targetRAddr : targetWAddr;
        value = heap.derefAddr(targetAddr);
        // print('[TRACE Commit FCP] Dereferenced VarRef(${(entry.value as VarRef).varId}) → $value');
      }

      // Use heap.bindVariable() to properly trigger callbacks and handle suspensions
      // This ensures onBind callbacks for external I/O are invoked
      final valueAsTerm = value is Term ? value : ConstTerm(value);
      final acts = heap.bindVariable(varId, valueAsTerm);
      activations.addAll(acts);
    }

    // CRITICAL FIX: Re-dereference all bound cells that contain VarRef
    // This handles dependencies in σ̂w (e.g., W1002→V1005, W1005→nil)
    // After first pass: W1002 contains VarRef(1005), W1005 contains nil
    // After second pass: W1002 contains nil (dereferenced through chain)
    // print('[TRACE Commit FCP] Re-dereferencing cells with VarRef values...');
    for (final varId in sigmaHat.keys) {
      final (wAddr, rAddr) = heap.varTable[varId]!;
      final wContent = heap.cells[wAddr].content;

      if (wContent is VarRef) {
        // Dereference again (target may now be bound)
        final (targetWAddr, _) = heap.varTable[wContent.varId]!;
        final derefValue = heap.derefAddr(targetWAddr);

        if (derefValue is! VarRef) {
          // Target is now bound - update both cells
          heap.cells[wAddr].content = derefValue;
          heap.cells[rAddr].content = derefValue;
          // print('[TRACE Commit FCP]   W$varId: VarRef(${wContent.varId}) → $derefValue');
        }
      }
    }

    // print('[TRACE Commit FCP] Total goals reactivated: ${activations.length}');
    return activations;
  }

  /// Walk suspension list and activate armed records (FCP lines 247-253)
  static void _walkAndActivate(SuspensionListNode? list, List<GoalRef> acts) {
    var current = list;

    while (current != null) {
      if (current.armed) {
        acts.add(GoalRef(current.goalId!, current.resumePC));
        current.record.disarm();  // Disarm shared record - affects all nodes
      }
      current = current.next;
    }
  }

  /// Forward suspension list to another variable (for reader chains)
  /// When binding W → R? where R is unbound, suspensions waiting on W should
  /// be moved to R's reader cell so they wake when R is eventually bound.
  static void _forwardSuspensions(HeapFCP heap, SuspensionListNode? list, int targetVarId) {
    final (_, targetRAddr) = heap.varTable[targetVarId]!;
    var current = list;

    while (current != null) {
      if (current.armed) {
        // Create a new node sharing the same SuspensionRecord
        // This ensures disarming one disarms all copies (FCP shared state)
        final newNode = SuspensionListNode(current.record);
        final targetContent = heap.cells[targetRAddr].content;
        newNode.next = targetContent is SuspensionListNode ? targetContent : null;
        heap.cells[targetRAddr].content = newNode;
      }
      current = current.next;
    }
  }

}
